# 题伴 AI V1.6（Android APK 工程）

这是一个可由 Android Gradle Plugin 构建的 Android 工程。当前首个可构建版本提供：
- DeepSeek 文本题目分析；
- 推荐答案与解释展示；
- API Key 本机保存；
- 不包含第三方平台自动点击、自动提交或自动翻页。

## 当前版本限制
此工程目前使用“粘贴题干和选项”的方式输入题目，尚未集成屏幕 OCR / 无障碍页面识别。它是 APK 构建工程，不是已经编译好的 APK。需要在 Android Studio 或 GitHub Actions 中构建后安装。

## 构建 APK
1. 将整个工程上传到你自己的 GitHub 仓库，默认分支命名为 `main`。
2. 打开仓库的 **Actions** 页面，运行 **Build Android APK** 工作流（首次可能需要启用 Actions）。
3. 构建成功后，进入该次运行页面，在 **Artifacts** 下载 `TiBanAI-debug-apk`。
4. 解压得到 `app-debug.apk`，传到 Android 手机安装。手机可能需要允许该来源安装应用。

也可用 Android Studio 打开本目录，等待 Gradle Sync 完成，然后运行 `:app:assembleDebug`。

## DeepSeek
在应用内粘贴你自己的 API Key。请求使用 `https://api.deepseek.com/chat/completions` 和 `deepseek-chat`。API 使用可能产生费用，请查看 DeepSeek 账户的计费与额度。

## 安全提醒
API Key 保存在应用本机私有偏好设置中，但 APK 内客户端密钥仍可能被有能力的人提取。不要把个人密钥提交到 Git 仓库，也不要把 APK 分发给他人时复用自己的 Key。正式公开发布应通过你控制的服务端代理管理密钥。
