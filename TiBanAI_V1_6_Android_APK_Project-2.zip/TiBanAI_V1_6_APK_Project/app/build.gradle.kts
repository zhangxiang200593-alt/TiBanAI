plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.tibanai.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.tibanai.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 16
        versionName = "1.6"
    }
}
