package com.tibanai.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var apiKey: EditText
    private lateinit var question: EditText
    private lateinit var result: TextView
    private lateinit var analyze: Button
    private val prefs by lazy { getSharedPreferences("tibanai_local", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(245, 247, 250)
        window.navigationBarColor = android.graphics.Color.BLACK

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
            setBackgroundColor(android.graphics.Color.rgb(245, 247, 250))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val title = TextView(this).apply {
            text = "题伴 AI"
            textSize = 28f
            setTypeface(null, Typeface.BOLD)
            setTextColor(android.graphics.Color.rgb(25, 40, 65))
        }
        content.addView(title)
        content.addView(label("DeepSeek 智能题目分析 · V1.6"))
        content.addView(label("API Key（仅保存在本机）"))
        apiKey = EditText(this).apply {
            hint = "粘贴 DeepSeek API Key"
            inputType = 129
            setText(prefs.getString("api_key", "") ?: "")
        }
        content.addView(apiKey, fieldParams())

        content.addView(label("题目与选项"))
        question = EditText(this).apply {
            hint = "例如：题干……\\nA. 选项一\\nB. 选项二\\nC. 选项三\\nD. 选项四"
            minLines = 7
            gravity = android.view.Gravity.TOP
            setPadding(dp(12), dp(12), dp(12), dp(12))
            textSize = 16f
        }
        content.addView(question, fieldParams())

        analyze = Button(this).apply {
            text = "让 DeepSeek 分析答案"
            setOnClickListener { analyzeQuestion() }
        }
        content.addView(analyze, fieldParams())

        content.addView(label("分析结果"))
        result = TextView(this).apply {
            text = "填写题目和选项后，点击上方按钮。"
            textSize = 16f
            setTextColor(android.graphics.Color.rgb(35, 45, 60))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(android.graphics.Color.WHITE)
        }
        content.addView(result, fieldParams())
        content.addView(label("提示：本版本通过粘贴题目文字进行分析；答案仅供核对，AI 可能出错。"))
        setContentView(page)
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(android.graphics.Color.rgb(70, 85, 105))
        setPadding(0, dp(14), 0, dp(6))
    }

    private fun fieldParams() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(8) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun analyzeQuestion() {
        val key = apiKey.text.toString().trim()
        val prompt = question.text.toString().trim()
        if (key.isEmpty()) { apiKey.error = "请填写 DeepSeek API Key"; return }
        if (prompt.isEmpty()) { question.error = "请先填写题目和选项"; return }

        prefs.edit().putString("api_key", key).apply()
        analyze.isEnabled = false
        result.text = "正在请求 DeepSeek 分析……"
        executor.execute {
            try {
                val answer = callDeepSeek(key, prompt)
                runOnUiThread { result.text = answer; analyze.isEnabled = true }
            } catch (e: Exception) {
                runOnUiThread {
                    result.text = "请求失败：${e.message ?: "未知错误"}\\n请检查网络、API Key 和账户额度。"
                    analyze.isEnabled = true
                }
            }
        }
    }

    private fun callDeepSeek(key: String, prompt: String): String {
        val conn = (URL("https://api.deepseek.com/chat/completions").openConnection() as HttpURLConnection)
        conn.requestMethod = "POST"
        conn.connectTimeout = 20000
        conn.readTimeout = 60000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Authorization", "Bearer $key")
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content",
                "你是严谨的学习辅导助手。分析用户提供的题目和选项，给出最可能答案及简明推理。若信息不足或题目有歧义，明确说明，不要编造。请用中文回答，并标明答案选项。"))
            .put(JSONObject().put("role", "user").put("content", prompt))
        val body = JSONObject()
            .put("model", "deepseek-chat")
            .put("messages", messages)
            .put("temperature", 0.1)
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        conn.disconnect()
        if (code !in 200..299) throw IllegalStateException("HTTP $code：$text")
        val json = JSONObject(text)
        return json.getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
