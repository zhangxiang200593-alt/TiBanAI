# 题伴 AI V1.7 Android 工程

## 新增功能
- 从手机相册选择题目截图，使用 ML Kit 中文 OCR 提取文字。
- OCR 结果填入题目框，用户可检查和修改后再交给 DeepSeek。
- 保存最近 50 条题目与 AI 分析结果，可查看和清空历史。
- 保留手动粘贴题目和 DeepSeek 分析功能。

## 构建
使用 Android Studio 打开工程，或通过 GitHub Actions 执行 `:app:assembleDebug`。
要求 JDK 17、Android SDK Platform 35、Build Tools 35.0.0。
APK 输出：`app/build/outputs/apk/debug/app-debug.apk`。

## 使用
1. 安装 APK。
2. 填写 DeepSeek API Key。
3. 从相册选择题目截图，或粘贴题目文字。
4. 检查 OCR 文字，必要时修正，再点击分析。
5. 在“查看错题 / 分析历史”中回看最近 50 条记录。

## 说明
本版本仅对用户主动选择的图片做 OCR，不读取其他应用实时屏幕，不自动点击第三方平台或自动翻页。OCR 和 AI 结果都可能出错，请核对。
API Key 保存在应用私有本地设置中，但 APK 客户端密钥仍可能被提取；不要提交密钥到 GitHub。API 调用可能产生费用。
