package com.tibanai.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.TextRecognition
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("tibanai_local", MODE_PRIVATE) }
    private lateinit var apiKey: EditText
    private lateinit var question: EditText
    private lateinit var result: TextView
    private lateinit var analyze: Button
    private lateinit var pickImage: Button
    private lateinit var historyButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(18))
            setBackgroundColor(0xFFF5F7FA.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(TextView(this).apply {
            text = "题伴 AI"
            textSize = 28f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF192841.toInt())
        })
        content.addView(label("V1.7 · 图片识题 · DeepSeek 分析 · 错题历史"))
        content.addView(label("DeepSeek API Key（仅保存在本机）"))
        apiKey = EditText(this).apply {
            hint = "粘贴 DeepSeek API Key"
            inputType = 129
            setText(prefs.getString("api_key", "") ?: "")
        }
        content.addView(apiKey, fieldParams())

        content.addView(label("题目与选项"))
        question = EditText(this).apply {
            hint = "可粘贴题目文字，也可从相册导入截图识别"
            minLines = 7
            gravity = android.view.Gravity.TOP
            setPadding(dp(12), dp(12), dp(12), dp(12))
            textSize = 16f
        }
        content.addView(question, fieldParams())

        pickImage = Button(this).apply {
            text = "从相册选择题目截图并识别"
            setOnClickListener { chooseImage() }
        }
        content.addView(pickImage, fieldParams())

        analyze = Button(this).apply {
            text = "让 DeepSeek 分析答案"
            setOnClickListener { analyzeQuestion() }
        }
        content.addView(analyze, fieldParams())

        historyButton = Button(this).apply {
            text = "查看错题 / 分析历史"
            setOnClickListener { showHistory() }
        }
        content.addView(historyButton, fieldParams())

        content.addView(label("分析结果"))
        result = TextView(this).apply {
            text = "导入截图或填写题目后，点击分析。"
            textSize = 16f
            setTextColor(0xFF232D3C.toInt())
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(android.graphics.Color.WHITE)
        }
        content.addView(result, fieldParams())
        content.addView(label("提示：OCR 可能识别错误，请核对题干和选项。AI 推荐答案仅供学习参考。"))
        setContentView(page)
    }

    private fun label(s: String) = TextView(this).apply {
        text = s
        textSize = 14f
        setTextColor(0xFF465569.toInt())
        setPadding(0, dp(13), 0, dp(6))
    }

    private fun fieldParams() = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
        .apply { bottomMargin = dp(7) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun chooseImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(intent, 701)
    }

    @Deprecated("Deprecated in Android but retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 701 || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        result.text = "正在识别图片文字……"
        pickImage.isEnabled = false
        executor.execute {
            try {
                val image = InputImage.fromFilePath(this, uri)
                val recognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
                recognizer.process(image)
                    .addOnSuccessListener { visionText ->
                        val recognized = visionText.text.trim()
                        runOnUiThread {
                            question.setText(recognized)
                            result.text = if (recognized.isBlank()) "没有识别到文字，请换一张清晰截图。" else "识别完成，请检查题干和选项后再分析。"
                            pickImage.isEnabled = true
                        }
                        recognizer.close()
                    }
                    .addOnFailureListener { e ->
                        runOnUiThread {
                            result.text = "图片识别失败：${e.message}"
                            pickImage.isEnabled = true
                        }
                        recognizer.close()
                    }
            } catch (e: Exception) {
                runOnUiThread {
                    result.text = "无法读取图片：${e.message}"
                    pickImage.isEnabled = true
                }
            }
        }
    }

    private fun analyzeQuestion() {
        val key = apiKey.text.toString().trim()
        val prompt = question.text.toString().trim()
        if (key.isEmpty()) { apiKey.error = "请填写 DeepSeek API Key"; return }
        if (prompt.isEmpty()) { question.error = "请先填写题目和选项"; return }
        prefs.edit().putString("api_key", key).apply()
        analyze.isEnabled = false
        result.text = "正在请求 DeepSeek 分析……"
        executor.execute {
            try {
                val answer = callDeepSeek(key, prompt)
                saveHistory(prompt, answer)
                runOnUiThread { result.text = answer; analyze.isEnabled = true }
            } catch (e: Exception) {
                runOnUiThread {
                    result.text = "请求失败：${e.message ?: "未知错误"}\n请检查网络、API Key 和账户额度。"
                    analyze.isEnabled = true
                }
            }
        }
    }

    private fun callDeepSeek(key: String, prompt: String): String {
        val conn = URL("https://api.deepseek.com/chat/completions").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 20000
        conn.readTimeout = 60000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Authorization", "Bearer $key")
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content",
                "你是严谨的学习辅导助手。分析题目和选项，给出最可能答案、推理和知识点。信息不足或有歧义时明确说明，不要编造。用中文回答并标明选项。"))
            .put(JSONObject().put("role", "user").put("content", prompt))
        val body = JSONObject().put("model", "deepseek-chat")
            .put("messages", messages).put("temperature", 0.1)
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        conn.disconnect()
        if (code !in 200..299) throw IllegalStateException("HTTP $code：$text")
        return JSONObject(text).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }

    private fun saveHistory(prompt: String, answer: String) {
        val old = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        val updated = JSONArray()
        updated.put(JSONObject().put("time", System.currentTimeMillis())
            .put("question", prompt).put("answer", answer))
        for (i in 0 until minOf(old.length(), 49)) updated.put(old.getJSONObject(i))
        prefs.edit().putString("history", updated.toString()).apply()
    }

    private fun showHistory() {
        val history = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        if (history.length() == 0) {
            AlertDialog.Builder(this).setTitle("分析历史").setMessage("还没有保存的记录。")
                .setPositiveButton("知道了", null).show()
            return
        }
        val labels = Array(history.length()) { i ->
            val item = history.getJSONObject(i)
            val date = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(item.optLong("time")))
            "$date  ${item.optString("question").replace("\n", " ").take(42)}"
        }
        AlertDialog.Builder(this).setTitle("分析历史（最近 50 条）")
            .setItems(labels) { _, which ->
                val item = history.getJSONObject(which)
                question.setText(item.optString("question"))
                result.text = item.optString("answer")
            }
            .setNeutralButton("清空历史") { _, _ ->
                prefs.edit().putString("history", "[]").apply()
                Toast.makeText(this, "历史记录已清空", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("关闭", null).show()
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
