# 题伴 AI V1.8 Android 工程

## 新增功能
- 错题本显示最近 50 条记录及掌握统计。
- 单条记录可标记“已掌握”或“需复习”，也可删除。
- 支持清空全部历史。
- 支持通过 Android 分享菜单导出文本学习记录。
- 保留 V1.7 相册中文 OCR、DeepSeek 分析和本地历史。

## 构建
JDK 17、Android SDK Platform 35、Build Tools 35.0.0。使用 Android Studio 或 GitHub Actions 构建 `:app:assembleDebug`。
APK 输出：`app/build/outputs/apk/debug/app-debug.apk`。

## 隐私提示
题目历史和 API Key 保存在应用本机私有设置中。卸载应用可能清除本地数据。API Key 不要提交到 GitHub；客户端密钥仍可能被提取。AI/OCR 结果可能出错，请核对。
