# 题伴 AI V2.1 Android 工程

## V2.1 修复
- 修复错题本详情查看：点击记录后显示独立的可滚动详情窗口。
- 详情窗口分别展示保存时间、题目内容、参考答案与详细解析、复习状态。
- 增加复制题目和解析功能。
- 保留原有本机历史记录 JSON 格式、悬浮球、用户主动屏幕捕获、中文 OCR、DeepSeek 分析及复习状态操作。

## 构建
使用 JDK 17、Android SDK Platform 35 构建 `:app:assembleDebug`。APK 输出：`app/build/outputs/apk/debug/app-debug.apk`。

## 重要说明
本次修改只调整历史记录详情展示，不迁移或清空 SharedPreferences 中的 `history` 数据。源码包已生成，但当前环境没有 Android Gradle 构建环境，因此尚未编译 APK，也未完成真机验证。请通过现有 GitHub Actions 工作流编译后安装测试。若覆盖安装提示签名不一致，请先导出学习记录并备份 API Key，再按提示处理；卸载可能清除本机数据。

屏幕捕获需由用户主动授权。应用不自动点击、选择、提交或翻页。API Key 不要上传到 GitHub；客户端密钥可能被提取，API 调用可能产生费用。
