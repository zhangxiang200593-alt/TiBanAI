package com.tibanai.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class FloatingCaptureService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val worker = Executors.newSingleThreadExecutor()
    private var busy = false
    private val channelId = "tibanai_capture"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(1901, buildNotification())
        showBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("result_code", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra("projection_data", Intent::class.java)
        } else {
            intent?.getParcelableExtra("projection_data")
        }
        if (code != Activity.RESULT_OK || data == null) {
            Toast.makeText(this, "没有获得屏幕捕获授权", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(code, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, Handler(mainLooper))
            prepareCapture()
        } catch (e: Exception) {
            Toast.makeText(this, "屏幕捕获初始化失败：${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun prepareCapture() {
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection?.createVirtualDisplay(
            "TiBanAI-Screen", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, null
        )
    }

    private fun overlayParams(): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 260 }
    }

    private fun showBubble() {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        val view = TextView(this).apply {
            text = "题伴\nAI"
            textSize = 13f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(18, 12, 18, 12)
            setBackgroundColor(0xFF315EAA.toInt())
            setOnClickListener { if (panel == null) showPanel() else hidePanel() }
        }
        bubble = view
        try { wm.addView(view, overlayParams()) } catch (_: Exception) { stopSelf() }
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            setBackgroundColor(0xFFF8FAFD.toInt())
        }
        val title = TextView(this).apply { text = "题伴 AI · 屏幕识题"; textSize = 18f; setTypeface(null, Typeface.BOLD); setTextColor(0xFF172B4D.toInt()) }
        val output = TextView(this).apply { text = "点击下方按钮，识别当前屏幕题目。"; textSize = 14f; setTextColor(0xFF263238.toInt()); setPadding(0, 12, 0, 12) }
        val scroll = ScrollView(this).apply { addView(output) }
        val capture = Button(this).apply { text = "识别当前屏幕"; setOnClickListener { captureAndAnalyze(output, this) } }
        val close = Button(this).apply { text = "收起面板"; setOnClickListener { hidePanel() } }
        val stop = Button(this).apply { text = "关闭悬浮助手"; setOnClickListener { stopSelf() } }
        box.addView(title)
        box.addView(scroll, LinearLayout.LayoutParams(dp(300), dp(230)))
        box.addView(capture)
        box.addView(close)
        box.addView(stop)
        panel = box
        val p = overlayParams().apply { width = dp(330); height = WindowManager.LayoutParams.WRAP_CONTENT; x = 12; y = 150; flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN }
        try { wm.addView(box, p) } catch (_: Exception) { panel = null }
    }

    private fun hidePanel() { panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel = null }

    private fun captureAndAnalyze(output: TextView, button: Button) {
        if (busy) return
        busy = true
        button.isEnabled = false
        output.text = "正在截取当前屏幕……"
        panel?.visibility = android.view.View.GONE
        bubble?.visibility = android.view.View.GONE
        Handler(mainLooper).postDelayed({
            worker.execute {
                try {
                    val image = reader?.acquireLatestImage() ?: throw IllegalStateException("暂时无法获取屏幕图像，请稍后重试")
                    restoreOverlay()
                    val plane = image.planes[0]
                    val buffer = plane.buffer
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * image.width
                    val full = Bitmap.createBitmap(image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888)
                    full.copyPixelsFromBuffer(buffer)
                    val bitmap = Bitmap.createBitmap(full, 0, 0, image.width, image.height)
                    full.recycle()
                    image.close()
                    val input = InputImage.fromBitmap(bitmap, 0)
                    val recognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
                    recognizer.process(input)
                        .addOnSuccessListener { vision ->
                            val text = vision.text.trim()
                            recognizer.close(); bitmap.recycle()
                            if (text.isBlank()) showOutput(output, button, "没有识别到文字。请确保题干和选项完整显示，再试一次。")
                            else analyzeText(text, output, button)
                        }
                        .addOnFailureListener { e ->
                            recognizer.close(); bitmap.recycle()
                            showOutput(output, button, "OCR 识别失败：${e.message}")
                        }
                } catch (e: Exception) { restoreOverlay(); showOutput(output, button, "识别失败：${e.message}") }
            }
        }, 650)
    }

    private fun restoreOverlay() {
        Handler(mainLooper).post {
            panel?.visibility = android.view.View.VISIBLE
            bubble?.visibility = android.view.View.VISIBLE
        }
    }

    private fun analyzeText(text: String, output: TextView, button: Button) {
        worker.execute {
            try {
                val key = getSharedPreferences("tibanai_local", MODE_PRIVATE).getString("api_key", "") ?: ""
                if (key.isBlank()) throw IllegalStateException("请先回到题伴 AI 主界面填写 API Key")
                val answer = callDeepSeek(key, text)
                saveHistory(text, answer)
                showOutput(output, button, "【识别到的题目】\n$text\n\n【DeepSeek 学习分析】\n$answer")
            } catch (e: Exception) { showOutput(output, button, "分析失败：${e.message}") }
        }
    }

    private fun callDeepSeek(key: String, prompt: String): String {
        val conn = URL("https://api.deepseek.com/chat/completions").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"; conn.connectTimeout = 20000; conn.readTimeout = 60000; conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Authorization", "Bearer $key")
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content", "你是严谨的学习辅导助手。先判断题型（单选、多选、判断、填空、简答或其他）；若包含多道题，按题号逐题分析。每题输出【题型】【参考答案】【把握程度】【解析】【知识点】【需要核对】。把握程度分高/中/低，并给出0-100的模型自评分数，明确这不是校准概率。答案需列出选项字母及对应内容；多选题列出全部可能正确项。题干/选项不完整或有歧义时明确指出，不得猜测或编造。只提供学习参考，不操作其他应用。用中文回答。"))
            .put(JSONObject().put("role", "user").put("content", prompt))
        val body = JSONObject().put("model", "deepseek-chat").put("messages", messages).put("temperature", 0.1)
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        conn.disconnect()
        if (code !in 200..299) throw IllegalStateException("HTTP $code：$response")
        return JSONObject(response).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }

    private fun saveHistory(question: String, answer: String) {
        val prefs = getSharedPreferences("tibanai_local", MODE_PRIVATE)
        val old = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        val updated = JSONArray().put(JSONObject().put("time", System.currentTimeMillis()).put("question", question).put("answer", answer).put("review", "待复习"))
        for (i in 0 until minOf(old.length(), 49)) updated.put(old.getJSONObject(i))
        prefs.edit().putString("history", updated.toString()).apply()
    }

    private fun showOutput(view: TextView, button: Button, message: String) {
        Handler(mainLooper).post { view.text = message; button.isEnabled = true; busy = false }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "题伴 AI 悬浮识题", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val pending = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
            .setContentTitle("题伴 AI 悬浮识题运行中").setContentText("点击屏幕右侧悬浮球识别当前页面")
            .setSmallIcon(android.R.drawable.ic_menu_search).setContentIntent(pending).build()
        else @Suppress("DEPRECATION") (Notification.Builder(this).setContentTitle("题伴 AI 悬浮识题运行中").setSmallIcon(android.R.drawable.ic_menu_search).build())
    }

    override fun onDestroy() {
        hidePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        virtualDisplay?.release(); reader?.close(); projection?.stop()
        worker.shutdownNow()
        super.onDestroy()
    }
}
