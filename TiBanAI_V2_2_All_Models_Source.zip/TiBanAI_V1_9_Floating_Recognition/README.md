# 题伴 AI V2.2（自定义 API + 模型切换版）

本版本在 V2.1 基础上修复历史记录详情展示，并增加自定义 OpenAI 兼容 API 配置。

## API 配置
- Base URL 默认：`https://api.supxh.xin/v1`
- 模型名称：可手动填写完整 Model ID，也可点击“从 API 平台获取全部可用模型并切换”，通过 GET /v1/models 读取账号可用列表并选择。截图中的 Gemini 3 Flash、Gemini 2.5 Pro、Gemini 3.1 Pro、Claude Sonnet 4.5、Claude Opus 4.5、入梦 Flash，只要平台在当前 Key 的模型列表中返回，就可以选择调用。
- API Key：在手机 App 内填写，仅保存在本机 SharedPreferences；不要把密钥发送给他人。
- 请求路径按 OpenAI Chat Completions 兼容格式拼接为 `/chat/completions`。
- 若 Base URL 已经以 `/chat/completions` 结尾，则直接使用。

## 重要说明
- 本项目通过 OpenAI 兼容 Chat Completions 接口调用模型；是否能调用某个 Gemini / Claude / 入梦模型，取决于中转平台是否将该模型开放在兼容接口、当前 Key 是否有权限。模型列表按钮只显示服务端实际返回的 Model ID，不猜测名称。原生 Anthropic/Gemini 专有协议不在本版本范围内。
- 用户需要自行确认模型 ID、密钥、余额及服务商条款。第三方中转服务可能处理请求内容，请勿发送隐私或敏感信息。
- 本源码包尚未在此环境完成 Gradle 编译或 Android 真机验证；请通过原 GitHub Actions 工作流编译后测试。
- 不会自动操作第三方学习平台；AI 输出仅供学习参考，由用户自行核对。
