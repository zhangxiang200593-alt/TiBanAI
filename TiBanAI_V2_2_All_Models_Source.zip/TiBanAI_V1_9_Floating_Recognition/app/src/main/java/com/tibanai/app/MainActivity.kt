package com.tibanai.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.media.projection.MediaProjectionManager
import android.provider.Settings
import android.content.ComponentName
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.TextRecognition
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("tibanai_local", MODE_PRIVATE) }
    private lateinit var apiKey: EditText
    private lateinit var apiBaseUrl: EditText
    private lateinit var modelName: EditText
    private lateinit var question: EditText
    private lateinit var result: TextView
    private lateinit var analyze: Button
    private lateinit var pickImage: Button
    private lateinit var historyButton: Button
    private lateinit var floatingButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(18))
            setBackgroundColor(0xFFF5F7FA.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(TextView(this).apply {
            text = "题伴 AI"
            textSize = 28f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF192841.toInt())
        })
        content.addView(label("V2.2 · 自定义 OpenAI 兼容 API · 学习分析"))
        content.addView(label("API 接口地址（Base URL）"))
        apiBaseUrl = EditText(this).apply {
            hint = "https://api.supxh.xin/v1"
            setSingleLine(true)
            setText(prefs.getString("api_base_url", "https://api.supxh.xin/v1") ?: "https://api.supxh.xin/v1")
        }
        content.addView(apiBaseUrl, fieldParams())
        content.addView(label("模型名称（从 API 平台的可用模型列表复制）"))
        modelName = EditText(this).apply {
            hint = "例如 gemini-3.1-pro（请填写你账号可用的模型 ID）"
            setSingleLine(true)
            setText(prefs.getString("model_name", "") ?: "")
        }
        content.addView(modelName, fieldParams())
        content.addView(label("API Key（仅保存在本机，不要发给他人）"))
        apiKey = EditText(this).apply {
            hint = "粘贴 API 平台提供的密钥"
            inputType = 129
            setText(prefs.getString("api_key", "") ?: "")
        }
        content.addView(apiKey, fieldParams())
        val fetchModelsButton = Button(this).apply {
            text = "从 API 平台获取全部可用模型并切换"
            setOnClickListener { fetchAndChooseModel() }
        }
        content.addView(fetchModelsButton, fieldParams())
        content.addView(label("提示：模型列表以你的 API Key 实际权限为准；默认建议 Gemini 2.5 Pro。"))

        content.addView(label("题目与选项"))
        question = EditText(this).apply {
            hint = "可粘贴题目文字，也可从相册导入截图识别"
            minLines = 7
            gravity = android.view.Gravity.TOP
            setPadding(dp(12), dp(12), dp(12), dp(12))
            textSize = 16f
        }
        content.addView(question, fieldParams())

        pickImage = Button(this).apply {
            text = "从相册选择题目截图并识别"
            setOnClickListener { chooseImage() }
        }
        content.addView(pickImage, fieldParams())

        analyze = Button(this).apply {
            text = "让 AI 分析题目"
            setOnClickListener { analyzeQuestion() }
        }
        content.addView(analyze, fieldParams())

        floatingButton = Button(this).apply {
            text = "开启悬浮识题（显示在其他页面上方）"
            setOnClickListener { startFloatingRecognition() }
        }
        content.addView(floatingButton, fieldParams())

        historyButton = Button(this).apply {
            text = "错题本 / 学习统计"
            setOnClickListener { showHistory() }
        }
        content.addView(historyButton, fieldParams())
        val exportButton = Button(this).apply {
            text = "导出学习记录"
            setOnClickListener { exportHistory() }
        }
        content.addView(exportButton, fieldParams())

        content.addView(label("分析结果"))
        result = TextView(this).apply {
            text = "导入截图或填写题目后，点击分析。"
            textSize = 16f
            setTextColor(0xFF232D3C.toInt())
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(android.graphics.Color.WHITE)
        }
        content.addView(result, fieldParams())
        content.addView(label("提示：OCR 可能识别错误，请核对题干和选项。AI 推荐答案仅供学习参考。"))
        setContentView(page)
    }

    private fun fetchAndChooseModel() {
        val key = apiKey.text.toString().trim()
        val base = apiBaseUrl.text.toString().trim().trimEnd('/')
        if (key.isEmpty()) { apiKey.error = "请先填写 API Key"; return }
        if (base.isEmpty()) { apiBaseUrl.error = "请填写 API 接口地址"; return }
        Toast.makeText(this, "正在获取账号可用模型…", Toast.LENGTH_SHORT).show()
        executor.execute {
            var connection: HttpURLConnection? = null
            try {
                val root = when {
                    base.endsWith("/v1") -> base
                    else -> "$base/v1"
                }
                connection = (URL("$root/models").openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 15000
                    readTimeout = 20000
                    setRequestProperty("Authorization", "Bearer $key")
                    setRequestProperty("Accept", "application/json")
                }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                if (code !in 200..299) throw IllegalStateException("HTTP $code：${response.take(500)}")
                val json = JSONObject(response)
                val data = json.optJSONArray("data") ?: throw IllegalStateException("返回内容中没有 data 模型列表")
                val ids = ArrayList<String>()
                for (i in 0 until data.length()) {
                    val id = data.optJSONObject(i)?.optString("id", "")?.trim().orEmpty()
                    if (id.isNotEmpty() && !ids.contains(id)) ids.add(id)
                }
                if (ids.isEmpty()) throw IllegalStateException("接口返回的模型列表为空")
                runOnUiThread {
                    val preferred = ids.firstOrNull { it.equals("gemini-2.5-pro", true) }
                    if (modelName.text.isNullOrBlank() && preferred != null) modelName.setText(preferred)
                    AlertDialog.Builder(this)
                        .setTitle("选择模型（共 ${ids.size} 个可用）")
                        .setItems(ids.toTypedArray()) { _, which ->
                            modelName.setText(ids[which])
                            prefs.edit().putString("api_key", key).putString("api_base_url", base)
                                .putString("model_name", ids[which]).apply()
                            Toast.makeText(this, "已选择 ${ids[which]}", Toast.LENGTH_SHORT).show()
                        }
                        .setNegativeButton("取消", null)
                        .show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    AlertDialog.Builder(this)
                        .setTitle("获取模型列表失败")
                        .setMessage("${e.message ?: "未知错误"}\n\n请检查 API 地址、API Key、网络及平台是否开放 GET /v1/models。你也可以手动填写平台提供的 Model ID。")
                        .setPositiveButton("知道了", null).show()
                }
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun startFloatingRecognition() {
        if (apiKey.text.toString().trim().isEmpty()) {
            apiKey.error = "请先填写 API Key"
            Toast.makeText(this, "请先填写 API Key", Toast.LENGTH_LONG).show()
            return
        }
        val base = apiBaseUrl.text.toString().trim()
        val model = modelName.text.toString().trim()
        if (base.isEmpty()) { apiBaseUrl.error = "请填写 API 接口地址"; return }
        if (model.isEmpty()) { modelName.error = "请填写模型名称"; return }
        prefs.edit().putString("api_key", apiKey.text.toString().trim())
            .putString("api_base_url", base).putString("model_name", model).apply()
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            Toast.makeText(this, "请允许题伴 AI 显示在其他应用上层，然后返回再次点击按钮", Toast.LENGTH_LONG).show()
            return
        }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), 702)
    }

    private fun label(s: String) = TextView(this).apply {
        text = s
        textSize = 14f
        setTextColor(0xFF465569.toInt())
        setPadding(0, dp(13), 0, dp(6))
    }

    private fun fieldParams() = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
        .apply { bottomMargin = dp(7) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun chooseImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(intent, 701)
    }

    @Deprecated("Deprecated in Android but retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 702 && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, FloatingCaptureService::class.java).apply {
                putExtra("result_code", resultCode)
                putExtra("projection_data", data)
            }
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
            Toast.makeText(this, "悬浮识题已开启。切换到学习页面，点击悬浮球识别当前屏幕。", Toast.LENGTH_LONG).show()
            return
        }
        if (requestCode != 701 || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        result.text = "正在识别图片文字……"
        pickImage.isEnabled = false
        executor.execute {
            try {
                val image = InputImage.fromFilePath(this, uri)
                val recognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
                recognizer.process(image)
                    .addOnSuccessListener { visionText ->
                        val recognized = visionText.text.trim()
                        runOnUiThread {
                            question.setText(recognized)
                            result.text = if (recognized.isBlank()) "没有识别到文字，请换一张清晰截图。" else "识别完成，请检查题干和选项后再分析。"
                            pickImage.isEnabled = true
                        }
                        recognizer.close()
                    }
                    .addOnFailureListener { e ->
                        runOnUiThread {
                            result.text = "图片识别失败：${e.message}"
                            pickImage.isEnabled = true
                        }
                        recognizer.close()
                    }
            } catch (e: Exception) {
                runOnUiThread {
                    result.text = "无法读取图片：${e.message}"
                    pickImage.isEnabled = true
                }
            }
        }
    }

    private fun analyzeQuestion() {
        val key = apiKey.text.toString().trim()
        val base = apiBaseUrl.text.toString().trim()
        val model = modelName.text.toString().trim()
        val prompt = question.text.toString().trim()
        if (key.isEmpty()) { apiKey.error = "请填写 API Key"; return }
        if (base.isEmpty()) { apiBaseUrl.error = "请填写 API 接口地址"; return }
        if (model.isEmpty()) { modelName.error = "请填写模型名称"; return }
        if (prompt.isEmpty()) { question.error = "请先填写题目和选项"; return }
        prefs.edit().putString("api_key", key).putString("api_base_url", base)
            .putString("model_name", model).apply()
        analyze.isEnabled = false
        result.text = "正在请求模型 $model 分析……"
        executor.execute {
            try {
                val answer = callCompatibleApi(base, key, model, prompt)
                saveHistory(prompt, answer)
                runOnUiThread { result.text = answer; analyze.isEnabled = true }
            } catch (e: Exception) {
                runOnUiThread {
                    result.text = "请求失败：${e.message ?: "未知错误"}\n请检查网络、API Key 和账户额度。"
                    analyze.isEnabled = true
                }
            }
        }
    }

    private fun callCompatibleApi(baseUrl: String, key: String, model: String, prompt: String): String {
        val cleanBase = baseUrl.trim().trimEnd('/')
        val endpoint = when {
            cleanBase.endsWith("/chat/completions") -> cleanBase
            cleanBase.endsWith("/v1") -> "$cleanBase/chat/completions"
            else -> "$cleanBase/v1/chat/completions"
        }
        val conn = URL(endpoint).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 20000
        conn.readTimeout = 60000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Authorization", "Bearer $key")
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content",
                """你是严谨的学习辅导助手。请先判断题型（单选、多选、判断、填空、简答或其他）；如果输入中包含多道题，按题号逐题分析，不要把不同题目混在一起。每题按以下结构回答：
【题型】
【参考答案】明确写出选项字母及对应内容；多选题列出全部可能正确项；
【把握程度】高/中/低，并给出0-100的模型自评分数（这不是经过校准的概率）；
【解析】逐步解释判断依据；
【知识点】
【需要核对】指出题干、选项或OCR中可能缺失/模糊之处。
如果题目或选项不完整、存在歧义、无法确定唯一答案，必须明确说明并请求补充，不得猜测或伪造。用中文回答。仅提供学习参考，不操作其他应用。""".trimIndent()))
            .put(JSONObject().put("role", "user").put("content", prompt))
        val body = JSONObject().put("model", model)
            .put("messages", messages).put("temperature", 0.1)
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        conn.disconnect()
        if (code !in 200..299) throw IllegalStateException("HTTP $code：$text")
        return JSONObject(text).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }

    private fun saveHistory(prompt: String, answer: String) {
        val old = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        val updated = JSONArray()
        updated.put(JSONObject().put("time", System.currentTimeMillis())
            .put("question", prompt).put("answer", answer).put("review", "待复习"))
        for (i in 0 until minOf(old.length(), 49)) updated.put(old.getJSONObject(i))
        prefs.edit().putString("history", updated.toString()).apply()
    }

    private fun showHistory() {
        val history = loadHistory()
        if (history.length() == 0) {
            AlertDialog.Builder(this).setTitle("错题本").setMessage("还没有保存的记录。")
                .setPositiveButton("知道了", null).show()
            return
        }
        var mastered = 0
        var needsReview = 0
        for (i in 0 until history.length()) {
            when (history.getJSONObject(i).optString("review", "待复习")) {
                "已掌握" -> mastered++
                "需复习" -> needsReview++
            }
        }
        val summary = "共 ${history.length()} 条 · 已掌握 $mastered 条 · 需复习 $needsReview 条"
        val labels = Array(history.length()) { i ->
            val item = history.getJSONObject(i)
            val date = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(item.optLong("time")))
            "${item.optString("review", "待复习")} · $date · ${item.optString("question").replace("\n", " ").take(34)}"
        }
        AlertDialog.Builder(this).setTitle("错题本 / 学习统计").setMessage(summary)
            .setItems(labels) { _, which ->
                val item = history.getJSONObject(which)
                val actions = arrayOf("查看题目和解析", "标记为已掌握", "标记为需复习", "删除这条记录")
                AlertDialog.Builder(this).setTitle("记录操作").setItems(actions) { _, action ->
                    when (action) {
                        0 -> showHistoryDetail(item)
                        1, 2 -> {
                            item.put("review", if (action == 1) "已掌握" else "需复习")
                            history.put(which, item)
                            prefs.edit().putString("history", history.toString()).apply()
                            Toast.makeText(this, "复习状态已更新", Toast.LENGTH_SHORT).show()
                        }
                        3 -> {
                            val updated = JSONArray()
                            for (i in 0 until history.length()) if (i != which) updated.put(history.getJSONObject(i))
                            prefs.edit().putString("history", updated.toString()).apply()
                            Toast.makeText(this, "记录已删除", Toast.LENGTH_SHORT).show()
                        }
                    }
                }.setNegativeButton("取消", null).show()
            }
            .setNeutralButton("清空全部") { _, _ -> prefs.edit().putString("history", "[]").apply() }
            .setNegativeButton("关闭", null).show()
    }


    private fun showHistoryDetail(item: JSONObject) {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(8), dp(18), dp(8))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        fun addSection(title: String, value: String) {
            content.addView(TextView(this).apply {
                text = title
                textSize = 16f
                setTypeface(null, Typeface.BOLD)
                setTextColor(0xFF192841.toInt())
                setPadding(0, dp(12), 0, dp(5))
            })
            content.addView(TextView(this).apply {
                text = value.ifBlank { "（此记录没有保存该内容）" }
                textSize = 15f
                setTextColor(0xFF263445.toInt())
                setPadding(dp(10), dp(10), dp(10), dp(10))
                setBackgroundColor(0xFFF3F6FA.toInt())
            })
        }

        val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
            .format(Date(item.optLong("time")))
        addSection("保存时间", date)
        addSection("题目内容", item.optString("question"))
        addSection("参考答案与详细解析", item.optString("answer"))
        addSection("复习状态", item.optString("review", "待复习"))
        container.addView(scroll, LinearLayout.LayoutParams(-1, dp(440)))

        AlertDialog.Builder(this)
            .setTitle("历史记录详情")
            .setView(container)
            .setPositiveButton("关闭", null)
            .setNeutralButton("复制内容") { _, _ ->
                val text = "题目：\n${item.optString("question")}\n\n参考答案与解析：\n${item.optString("answer")}"
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("题伴 AI 历史记录", text))
                Toast.makeText(this, "题目和解析已复制", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun loadHistory(): JSONArray =
        try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }

    private fun exportHistory() {
        val history = loadHistory()
        if (history.length() == 0) {
            Toast.makeText(this, "暂无可导出的记录", Toast.LENGTH_SHORT).show()
            return
        }
        val out = StringBuilder("题伴 AI 学习记录\n\n")
        for (i in 0 until history.length()) {
            val item = history.getJSONObject(i)
            val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(item.optLong("time")))
            out.append("【").append(date).append("】（")
                .append(item.optString("review", "待复习")).append("）\n")
                .append("题目：").append(item.optString("question")).append("\n")
                .append("AI 分析：").append(item.optString("answer")).append("\n\n")
        }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "题伴 AI 学习记录")
            putExtra(Intent.EXTRA_TEXT, out.toString())
        }
        startActivity(Intent.createChooser(send, "导出学习记录"))
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
