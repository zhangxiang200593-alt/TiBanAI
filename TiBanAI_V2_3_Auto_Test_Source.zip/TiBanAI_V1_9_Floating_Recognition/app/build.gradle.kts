plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.tibanai.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.tibanai.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 23
        versionName = "2.3"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
dependencies {
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1")
}
