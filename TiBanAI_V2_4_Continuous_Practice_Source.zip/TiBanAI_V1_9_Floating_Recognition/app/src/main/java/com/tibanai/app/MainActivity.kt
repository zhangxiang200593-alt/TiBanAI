package com.tibanai.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.media.projection.MediaProjectionManager
import android.provider.Settings
import android.content.ComponentName
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.TextRecognition
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("tibanai_local", MODE_PRIVATE) }
    private lateinit var apiKey: EditText
    private lateinit var apiBaseUrl: EditText
    private lateinit var modelName: EditText
    private lateinit var question: EditText
    private lateinit var result: TextView
    private lateinit var analyze: Button
    private lateinit var pickImage: Button
    private lateinit var historyButton: Button
    private lateinit var floatingButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(18))
            setBackgroundColor(0xFFF5F7FA.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(TextView(this).apply {
            text = "题伴 AI"
            textSize = 28f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF192841.toInt())
        })
        content.addView(label("V2.4 · 自定义 OpenAI 兼容 API · 连续模拟答题"))
        content.addView(label("API 接口地址（Base URL）"))
        apiBaseUrl = EditText(this).apply {
            hint = "https://api.supxh.xin/v1"
            setSingleLine(true)
            setText(prefs.getString("api_base_url", "https://api.supxh.xin/v1") ?: "https://api.supxh.xin/v1")
        }
        content.addView(apiBaseUrl, fieldParams())
        content.addView(label("模型名称（从 API 平台的可用模型列表复制）"))
        modelName = EditText(this).apply {
            hint = "例如 gemini-3.1-pro（请填写你账号可用的模型 ID）"
            setSingleLine(true)
            setText(prefs.getString("model_name", "") ?: "")
        }
        content.addView(modelName, fieldParams())
        content.addView(label("API Key（仅保存在本机，不要发给他人）"))
        apiKey = EditText(this).apply {
            hint = "粘贴 API 平台提供的密钥"
            inputType = 129
            setText(prefs.getString("api_key", "") ?: "")
        }
        content.addView(apiKey, fieldParams())
        val fetchModelsButton = Button(this).apply {
            text = "从 API 平台获取全部可用模型并切换"
            setOnClickListener { fetchAndChooseModel() }
        }
        content.addView(fetchModelsButton, fieldParams())
        content.addView(label("提示：模型列表以你的 API Key 实际权限为准；默认建议 Gemini 2.5 Pro。"))

        content.addView(label("题目与选项"))
        question = EditText(this).apply {
            hint = "可粘贴题目文字，也可从相册导入截图识别"
            minLines = 7
            gravity = android.view.Gravity.TOP
            setPadding(dp(12), dp(12), dp(12), dp(12))
            textSize = 16f
        }
        content.addView(question, fieldParams())

        pickImage = Button(this).apply {
            text = "从相册选择题目截图并识别"
            setOnClickListener { chooseImage() }
        }
        content.addView(pickImage, fieldParams())

        analyze = Button(this).apply {
            text = "让 AI 分析题目"
            setOnClickListener { analyzeQuestion() }
        }
        content.addView(analyze, fieldParams())

        floatingButton = Button(this).apply {
            text = "开启悬浮识题（显示在其他页面上方）"
            setOnClickListener { startFloatingRecognition() }
        }
        content.addView(floatingButton, fieldParams())

        val practiceButton = Button(this).apply {
            text = "进入连续自动答题模拟测试（V2.4）"
            setOnClickListener { showBuiltInAutoTest() }
        }
        content.addView(practiceButton, fieldParams())

        historyButton = Button(this).apply {
            text = "错题本 / 学习统计"
            setOnClickListener { showHistory() }
        }
        content.addView(historyButton, fieldParams())
        val exportButton = Button(this).apply {
            text = "导出学习记录"
            setOnClickListener { exportHistory() }
        }
        content.addView(exportButton, fieldParams())

        content.addView(label("分析结果"))
        result = TextView(this).apply {
            text = "导入截图或填写题目后，点击分析。"
            textSize = 16f
            setTextColor(0xFF232D3C.toInt())
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(android.graphics.Color.WHITE)
        }
        content.addView(result, fieldParams())
        content.addView(label("提示：OCR 可能识别错误，请核对题干和选项。AI 推荐答案仅供学习参考。"))
        setContentView(page)
    }

    private fun fetchAndChooseModel() {
        val key = apiKey.text.toString().trim()
        val base = apiBaseUrl.text.toString().trim().trimEnd('/')
        if (key.isEmpty()) { apiKey.error = "请先填写 API Key"; return }
        if (base.isEmpty()) { apiBaseUrl.error = "请填写 API 接口地址"; return }
        Toast.makeText(this, "正在获取账号可用模型…", Toast.LENGTH_SHORT).show()
        executor.execute {
            var connection: HttpURLConnection? = null
            try {
                val root = when {
                    base.endsWith("/v1") -> base
                    else -> "$base/v1"
                }
                connection = (URL("$root/models").openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 15000
                    readTimeout = 20000
                    setRequestProperty("Authorization", "Bearer $key")
                    setRequestProperty("Accept", "application/json")
                }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                if (code !in 200..299) throw IllegalStateException("HTTP $code：${response.take(500)}")
                val json = JSONObject(response)
                val data = json.optJSONArray("data") ?: throw IllegalStateException("返回内容中没有 data 模型列表")
                val ids = ArrayList<String>()
                for (i in 0 until data.length()) {
                    val id = data.optJSONObject(i)?.optString("id", "")?.trim().orEmpty()
                    if (id.isNotEmpty() && !ids.contains(id)) ids.add(id)
                }
                if (ids.isEmpty()) throw IllegalStateException("接口返回的模型列表为空")
                runOnUiThread {
                    val preferred = ids.firstOrNull { it.equals("gemini-2.5-pro", true) }
                    if (modelName.text.isNullOrBlank() && preferred != null) modelName.setText(preferred)
                    AlertDialog.Builder(this)
                        .setTitle("选择模型（共 ${ids.size} 个可用）")
                        .setItems(ids.toTypedArray()) { _, which ->
                            modelName.setText(ids[which])
                            prefs.edit().putString("api_key", key).putString("api_base_url", base)
                                .putString("model_name", ids[which]).apply()
                            Toast.makeText(this, "已选择 ${ids[which]}", Toast.LENGTH_SHORT).show()
                        }
                        .setNegativeButton("取消", null)
                        .show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    AlertDialog.Builder(this)
                        .setTitle("获取模型列表失败")
                        .setMessage("${e.message ?: "未知错误"}\n\n请检查 API 地址、API Key、网络及平台是否开放 GET /v1/models。你也可以手动填写平台提供的 Model ID。")
                        .setPositiveButton("知道了", null).show()
                }
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun startFloatingRecognition() {
        if (apiKey.text.toString().trim().isEmpty()) {
            apiKey.error = "请先填写 API Key"
            Toast.makeText(this, "请先填写 API Key", Toast.LENGTH_LONG).show()
            return
        }
        val base = apiBaseUrl.text.toString().trim()
        val model = modelName.text.toString().trim()
        if (base.isEmpty()) { apiBaseUrl.error = "请填写 API 接口地址"; return }
        if (model.isEmpty()) { modelName.error = "请填写模型名称"; return }
        prefs.edit().putString("api_key", apiKey.text.toString().trim())
            .putString("api_base_url", base).putString("model_name", model).apply()
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            Toast.makeText(this, "请允许题伴 AI 显示在其他应用上层，然后返回再次点击按钮", Toast.LENGTH_LONG).show()
            return
        }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), 702)
    }

    private fun label(s: String) = TextView(this).apply {
        text = s
        textSize = 14f
        setTextColor(0xFF465569.toInt())
        setPadding(0, dp(13), 0, dp(6))
    }

    private fun fieldParams() = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
        .apply { bottomMargin = dp(7) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun chooseImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(intent, 701)
    }

    @Deprecated("Deprecated in Android but retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 702 && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, FloatingCaptureService::class.java).apply {
                putExtra("result_code", resultCode)
                putExtra("projection_data", data)
            }
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
            Toast.makeText(this, "悬浮识题已开启。切换到学习页面，点击悬浮球识别当前屏幕。", Toast.LENGTH_LONG).show()
            return
        }
        if (requestCode != 701 || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        result.text = "正在识别图片文字……"
        pickImage.isEnabled = false
        executor.execute {
            try {
                val image = InputImage.fromFilePath(this, uri)
                val recognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
                recognizer.process(image)
                    .addOnSuccessListener { visionText ->
                        val recognized = visionText.text.trim()
                        runOnUiThread {
                            question.setText(recognized)
                            result.text = if (recognized.isBlank()) "没有识别到文字，请换一张清晰截图。" else "识别完成，请检查题干和选项后再分析。"
                            pickImage.isEnabled = true
                        }
                        recognizer.close()
                    }
                    .addOnFailureListener { e ->
                        runOnUiThread {
                            result.text = "图片识别失败：${e.message}"
                            pickImage.isEnabled = true
                        }
                        recognizer.close()
                    }
            } catch (e: Exception) {
                runOnUiThread {
                    result.text = "无法读取图片：${e.message}"
                    pickImage.isEnabled = true
                }
            }
        }
    }

    private fun analyzeQuestion() {
        val key = apiKey.text.toString().trim()
        val base = apiBaseUrl.text.toString().trim()
        val model = modelName.text.toString().trim()
        val prompt = question.text.toString().trim()
        if (key.isEmpty()) { apiKey.error = "请填写 API Key"; return }
        if (base.isEmpty()) { apiBaseUrl.error = "请填写 API 接口地址"; return }
        if (model.isEmpty()) { modelName.error = "请填写模型名称"; return }
        if (prompt.isEmpty()) { question.error = "请先填写题目和选项"; return }
        prefs.edit().putString("api_key", key).putString("api_base_url", base)
            .putString("model_name", model).apply()
        analyze.isEnabled = false
        result.text = "正在请求模型 $model 分析……"
        executor.execute {
            try {
                val answer = callCompatibleApi(base, key, model, prompt)
                saveHistory(prompt, answer)
                runOnUiThread { result.text = answer; analyze.isEnabled = true }
            } catch (e: Exception) {
                runOnUiThread {
                    result.text = "请求失败：${e.message ?: "未知错误"}\n请检查网络、API Key 和账户额度。"
                    analyze.isEnabled = true
                }
            }
        }
    }

    private fun callCompatibleApi(baseUrl: String, key: String, model: String, prompt: String): String {
        val cleanBase = baseUrl.trim().trimEnd('/')
        val endpoint = when {
            cleanBase.endsWith("/chat/completions") -> cleanBase
            cleanBase.endsWith("/v1") -> "$cleanBase/chat/completions"
            else -> "$cleanBase/v1/chat/completions"
        }
        val conn = URL(endpoint).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 20000
        conn.readTimeout = 60000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Authorization", "Bearer $key")
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content",
                """你是严谨的学习辅导助手。请先判断题型（单选、多选、判断、填空、简答或其他）；如果输入中包含多道题，按题号逐题分析，不要把不同题目混在一起。每题按以下结构回答：
【题型】
【参考答案】明确写出选项字母及对应内容；多选题列出全部可能正确项；
【把握程度】高/中/低，并给出0-100的模型自评分数（这不是经过校准的概率）；
【解析】逐步解释判断依据；
【知识点】
【需要核对】指出题干、选项或OCR中可能缺失/模糊之处。
如果题目或选项不完整、存在歧义、无法确定唯一答案，必须明确说明并请求补充，不得猜测或伪造。用中文回答。仅提供学习参考，不操作其他应用。""".trimIndent()))
            .put(JSONObject().put("role", "user").put("content", prompt))
        val body = JSONObject().put("model", model)
            .put("messages", messages).put("temperature", 0.1)
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        conn.disconnect()
        if (code !in 200..299) throw IllegalStateException("HTTP $code：$text")
        return JSONObject(text).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }

    private fun saveHistory(prompt: String, answer: String) {
        val old = try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }
        val updated = JSONArray()
        updated.put(JSONObject().put("time", System.currentTimeMillis())
            .put("question", prompt).put("answer", answer).put("review", "待复习"))
        for (i in 0 until minOf(old.length(), 49)) updated.put(old.getJSONObject(i))
        prefs.edit().putString("history", updated.toString()).apply()
    }


    /**
     * 完全在题伴 AI 自己的模拟页面中运行自动答题演示。
     * 不读取或控制其他应用，不执行跨应用点击。
     */
    private fun showBuiltInAutoTest() {
        data class DemoQuestion(val prompt: String, val options: List<String>, val correct: String)
        val questions = listOf(
            DemoQuestion("下列哪一个是太阳系中最大的行星？", listOf("A. 地球", "B. 木星", "C. 火星", "D. 金星"), "B"),
            DemoQuestion("水的化学式是什么？", listOf("A. CO₂", "B. O₂", "C. H₂O", "D. NaCl"), "C"),
            DemoQuestion("一年有多少个月？", listOf("A. 10个月", "B. 11个月", "C. 12个月", "D. 13个月"), "C"),
            DemoQuestion("光合作用主要发生在植物细胞的哪种结构中？", listOf("A. 细胞核", "B. 线粒体", "C. 叶绿体", "D. 液泡"), "C"),
            DemoQuestion("下列哪一个数是质数？", listOf("A. 9", "B. 15", "C. 17", "D. 21"), "C")
        )
        val key = prefs.getString("api_key", "")?.trim().orEmpty()
        val base = prefs.getString("api_base_url", "https://api.supxh.xin/v1")?.trim().orEmpty()
        val model = prefs.getString("model_name", "")?.trim().orEmpty()
        if (key.isEmpty() || model.isEmpty()) {
            AlertDialog.Builder(this).setTitle("需要先配置 API")
                .setMessage("请先在主界面填写 API Key，并选择一个可用模型，然后再开始模拟测试。")
                .setPositiveButton("知道了", null).show()
            return
        }

        var index = 0
        var score = 0
        var answered = 0
        var busy = false
        var autoRunning = false
        var paused = false
        var delayMillis = 3000L
        val handler = android.os.Handler(mainLooper)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(8))
        }
        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(body)
        val progress = TextView(this).apply { textSize = 14f; setTextColor(0xFF526174.toInt()) }
        val promptView = TextView(this).apply {
            textSize = 18f; setTypeface(null, Typeface.BOLD); setTextColor(0xFF192841.toInt())
            setPadding(0, dp(12), 0, dp(12))
        }
        val optionsGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val speedLabel = label("连续答题间隔")
        val speedSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("1 秒（快速）", "3 秒（默认）", "5 秒（较慢）", "8 秒（仔细查看）"))
            setSelection(1)
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    delayMillis = listOf(1000L, 3000L, 5000L, 8000L)[position]
                }
            }
        }
        val status = TextView(this).apply {
            textSize = 14f; setTextColor(0xFF263445.toInt()); setPadding(0, dp(12), 0, dp(8))
        }
        val analyzeButton = Button(this).apply { text = "AI 分析并选择本题答案" }
        val nextButton = Button(this).apply { text = "手动下一题"; isEnabled = false }
        val startButton = Button(this).apply { text = "开始连续自动答题" }
        val pauseButton = Button(this).apply { text = "暂停"; isEnabled = false }
        val stopButton = Button(this).apply { text = "停止连续答题"; isEnabled = false }
        body.addView(progress)
        body.addView(promptView)
        body.addView(optionsGroup)
        body.addView(speedLabel)
        body.addView(speedSpinner)
        body.addView(startButton)
        body.addView(pauseButton)
        body.addView(stopButton)
        body.addView(status)
        body.addView(analyzeButton)
        body.addView(nextButton)
        root.addView(scroll, LinearLayout.LayoutParams(-1, dp(480)))

        lateinit var dialog: AlertDialog
        fun renderQuestion() {
            if (index >= questions.size) {
                autoRunning = false
                paused = false
                progress.text = "模拟测试完成 · 已答 $answered / ${questions.size} 题"
                promptView.text = "本轮测试结束"
                optionsGroup.removeAllViews()
                val percent = if (answered == 0) 0 else score * 100 / answered
                status.text = "正确 $score 题，错误 ${answered - score} 题，正确率 $percent%。\n本轮结果仅用于测试功能，不代表模型在真实题目中的准确率。"
                analyzeButton.isEnabled = false
                nextButton.isEnabled = false
                startButton.isEnabled = true
                pauseButton.isEnabled = false
                stopButton.isEnabled = false
                pauseButton.text = "暂停"
                return
            }
            val q = questions[index]
            progress.text = "第 ${index + 1} / ${questions.size} 题 · 已答 $answered 题 · 正确 $score 题"
            promptView.text = q.prompt
            optionsGroup.removeAllViews()
            q.options.forEachIndexed { i, option ->
                optionsGroup.addView(RadioButton(this).apply {
                    id = 1000 + i
                    text = option
                    textSize = 16f
                    isEnabled = false
                    setPadding(0, dp(5), 0, dp(5))
                })
            }
            status.text = if (autoRunning) "连续答题运行中。自动选择仅作用于本模拟页面。" else "等待 AI 分析。你可以单题测试，也可以开始连续自动答题。"
            analyzeButton.isEnabled = true
            analyzeButton.text = "AI 分析并选择本题答案"
            nextButton.isEnabled = false
        }

        fun advance() {
            if (index < questions.size) index++
            renderQuestion()
        }

        fun scheduleNext() {
            handler.removeCallbacksAndMessages(null)
            if (!autoRunning || paused) return
            status.text = "本题已完成，${delayMillis / 1000} 秒后自动进入下一题……"
            handler.postDelayed({
                if (!dialog.isShowing || !autoRunning || paused) return@postDelayed
                advance()
                if (autoRunning && index < questions.size) analyzeButton.performClick()
            }, delayMillis)
        }

        analyzeButton.setOnClickListener {
            if (busy || index >= questions.size) return@setOnClickListener
            handler.removeCallbacksAndMessages(null)
            busy = true
            analyzeButton.isEnabled = false
            nextButton.isEnabled = false
            status.text = "正在调用 $model 分析并识别推荐选项……"
            val q = questions[index]
            val fullPrompt = buildString {
                append("请回答下面这道单选题。必须先给出唯一选项字母，格式严格为【参考答案】A 或【参考答案】B 等，然后给出简短解析。\n")
                append(q.prompt).append("\n")
                q.options.forEach { append(it).append("\n") }
            }
            executor.execute {
                try {
                    val answerText = callCompatibleApi(base, key, model, fullPrompt)
                    val match = Regex("(?i)(?:【?参考答案】?|【?答案】?)\\s*[:：]?\\s*([A-D])\\b").find(answerText)
                        ?: Regex("(?i)\\b([A-D])\\s*[.、）)]").find(answerText)
                    val letter = match?.groupValues?.getOrNull(1)?.uppercase(Locale.ROOT)
                    runOnUiThread {
                        busy = false
                        if (!dialog.isShowing || index >= questions.size) return@runOnUiThread
                        if (letter == null || letter !in listOf("A", "B", "C", "D")) {
                            status.text = "无法可靠提取 A-D 选项，请检查模型原始回复后重试。\n\n${answerText.take(1600)}"
                            analyzeButton.isEnabled = true
                            if (autoRunning) { autoRunning = false; startButton.isEnabled = true; pauseButton.isEnabled = false; stopButton.isEnabled = false }
                            return@runOnUiThread
                        }
                        val chosenIndex = letter[0] - 'A'
                        if (chosenIndex !in q.options.indices) {
                            status.text = "模型给出的选项超出本题范围，请检查解析。\n\n${answerText.take(1200)}"
                            analyzeButton.isEnabled = true
                            if (autoRunning) { autoRunning = false; startButton.isEnabled = true; pauseButton.isEnabled = false; stopButton.isEnabled = false }
                            return@runOnUiThread
                        }
                        optionsGroup.check(1000 + chosenIndex)
                        val isCorrect = letter == q.correct
                        answered++
                        if (isCorrect) score++
                        saveHistory(fullPrompt, answerText)
                        val percent = score * 100 / answered
                        status.text = "AI 已选择：$letter（${if (isCorrect) "正确" else "错误，标准答案为 ${q.correct}"}）\n当前正确率：$percent%（$score / $answered）\n\n$answerText"
                        nextButton.isEnabled = true
                        analyzeButton.isEnabled = false
                        analyzeButton.text = "本题已完成"
                        if (autoRunning && !paused) scheduleNext()
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        busy = false
                        if (dialog.isShowing) {
                            status.text = "分析失败：${e.message ?: "未知错误"}"
                            analyzeButton.isEnabled = true
                            if (autoRunning) {
                                autoRunning = false
                                paused = false
                                startButton.isEnabled = true
                                pauseButton.isEnabled = false
                                stopButton.isEnabled = false
                            }
                        }
                    }
                }
            }
        }

        startButton.setOnClickListener {
            if (busy) return@setOnClickListener
            if (nextButton.isEnabled && index < questions.size) advance()
            if (index >= questions.size) {
                index = 0; score = 0; answered = 0
                renderQuestion()
            }
            autoRunning = true
            paused = false
            startButton.isEnabled = false
            pauseButton.isEnabled = true
            stopButton.isEnabled = true
            pauseButton.text = "暂停"
            analyzeButton.performClick()
        }
        pauseButton.setOnClickListener {
            if (!autoRunning) return@setOnClickListener
            if (!paused) {
                paused = true
                handler.removeCallbacksAndMessages(null)
                pauseButton.text = "继续"
                status.text = if (busy) "已请求暂停：当前 AI 请求完成后停止自动推进。" else "连续答题已暂停。"
            } else {
                paused = false
                pauseButton.text = "暂停"
                if (nextButton.isEnabled) scheduleNext() else if (!busy) analyzeButton.performClick()
            }
        }
        stopButton.setOnClickListener {
            autoRunning = false
            paused = false
            handler.removeCallbacksAndMessages(null)
            startButton.isEnabled = true
            pauseButton.isEnabled = false
            stopButton.isEnabled = false
            pauseButton.text = "暂停"
            status.text = "连续答题已停止。可以单题分析，或重新开始连续答题。"
        }
        nextButton.setOnClickListener {
            handler.removeCallbacksAndMessages(null)
            if (index < questions.size) advance()
            if (autoRunning && !paused && index < questions.size) analyzeButton.performClick()
        }
        renderQuestion()
        dialog = AlertDialog.Builder(this).setTitle("题伴 AI · 连续模拟答题")
            .setView(root).setNegativeButton("结束测试", null).create()
        dialog.setOnDismissListener {
            handler.removeCallbacksAndMessages(null)
            autoRunning = false
        }
        dialog.show()
    }

    private fun showHistory() {
        val history = loadHistory()
        if (history.length() == 0) {
            AlertDialog.Builder(this).setTitle("错题本").setMessage("还没有保存的记录。")
                .setPositiveButton("知道了", null).show()
            return
        }
        var mastered = 0
        var needsReview = 0
        for (i in 0 until history.length()) {
            when (history.getJSONObject(i).optString("review", "待复习")) {
                "已掌握" -> mastered++
                "需复习" -> needsReview++
            }
        }
        val summary = "共 ${history.length()} 条 · 已掌握 $mastered 条 · 需复习 $needsReview 条"
        val labels = Array(history.length()) { i ->
            val item = history.getJSONObject(i)
            val date = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(item.optLong("time")))
            "${item.optString("review", "待复习")} · $date · ${item.optString("question").replace("\n", " ").take(34)}"
        }
        AlertDialog.Builder(this).setTitle("错题本 / 学习统计").setMessage(summary)
            .setItems(labels) { _, which ->
                val item = history.getJSONObject(which)
                val actions = arrayOf("查看题目和解析", "标记为已掌握", "标记为需复习", "删除这条记录")
                AlertDialog.Builder(this).setTitle("记录操作").setItems(actions) { _, action ->
                    when (action) {
                        0 -> showHistoryDetail(item)
                        1, 2 -> {
                            item.put("review", if (action == 1) "已掌握" else "需复习")
                            history.put(which, item)
                            prefs.edit().putString("history", history.toString()).apply()
                            Toast.makeText(this, "复习状态已更新", Toast.LENGTH_SHORT).show()
                        }
                        3 -> {
                            val updated = JSONArray()
                            for (i in 0 until history.length()) if (i != which) updated.put(history.getJSONObject(i))
                            prefs.edit().putString("history", updated.toString()).apply()
                            Toast.makeText(this, "记录已删除", Toast.LENGTH_SHORT).show()
                        }
                    }
                }.setNegativeButton("取消", null).show()
            }
            .setNeutralButton("清空全部") { _, _ -> prefs.edit().putString("history", "[]").apply() }
            .setNegativeButton("关闭", null).show()
    }


    private fun showHistoryDetail(item: JSONObject) {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(8), dp(18), dp(8))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        fun addSection(title: String, value: String) {
            content.addView(TextView(this).apply {
                text = title
                textSize = 16f
                setTypeface(null, Typeface.BOLD)
                setTextColor(0xFF192841.toInt())
                setPadding(0, dp(12), 0, dp(5))
            })
            content.addView(TextView(this).apply {
                text = value.ifBlank { "（此记录没有保存该内容）" }
                textSize = 15f
                setTextColor(0xFF263445.toInt())
                setPadding(dp(10), dp(10), dp(10), dp(10))
                setBackgroundColor(0xFFF3F6FA.toInt())
            })
        }

        val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
            .format(Date(item.optLong("time")))
        addSection("保存时间", date)
        addSection("题目内容", item.optString("question"))
        addSection("参考答案与详细解析", item.optString("answer"))
        addSection("复习状态", item.optString("review", "待复习"))
        container.addView(scroll, LinearLayout.LayoutParams(-1, dp(440)))

        AlertDialog.Builder(this)
            .setTitle("历史记录详情")
            .setView(container)
            .setPositiveButton("关闭", null)
            .setNeutralButton("复制内容") { _, _ ->
                val text = "题目：\n${item.optString("question")}\n\n参考答案与解析：\n${item.optString("answer")}"
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("题伴 AI 历史记录", text))
                Toast.makeText(this, "题目和解析已复制", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun loadHistory(): JSONArray =
        try { JSONArray(prefs.getString("history", "[]")) } catch (_: Exception) { JSONArray() }

    private fun exportHistory() {
        val history = loadHistory()
        if (history.length() == 0) {
            Toast.makeText(this, "暂无可导出的记录", Toast.LENGTH_SHORT).show()
            return
        }
        val out = StringBuilder("题伴 AI 学习记录\n\n")
        for (i in 0 until history.length()) {
            val item = history.getJSONObject(i)
            val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(item.optLong("time")))
            out.append("【").append(date).append("】（")
                .append(item.optString("review", "待复习")).append("）\n")
                .append("题目：").append(item.optString("question")).append("\n")
                .append("AI 分析：").append(item.optString("answer")).append("\n\n")
        }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "题伴 AI 学习记录")
            putExtra(Intent.EXTRA_TEXT, out.toString())
        }
        startActivity(Intent.createChooser(send, "导出学习记录"))
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
